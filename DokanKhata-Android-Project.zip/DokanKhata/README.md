# DokanKhata — Android Daily Ledger

A native Android daily ledger app built with Kotlin, Jetpack Compose, and SQLite.
All records are stored locally on the device. No account or internet connection is required.

## Open and run

1. Install **Android Studio** on your computer.
2. Extract `DokanKhata-Android-Project.zip`.
3. In Android Studio choose **Open** and select the extracted `DokanKhata` folder.
4. Allow Android Studio to install the required Android Gradle Plugin / SDK components.
5. Connect an Android phone with USB debugging enabled, or start an Android emulator.
6. Press **Run ▶**.

The project uses JDK 17, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and compile SDK 35.
If Android Studio asks to install SDK 35 or platform build tools, accept the prompt.

## Features in this starter version

- Daily pages, one page per date
- Date search (ISO date or displayed date)
- Calendar date picker
- Four editable Bengali ledger columns: বিক্রি, মালামাল, ক্যাশ, বাকি
- Additional notes
- Automatic local SQLite saving as you type
- Open and delete existing pages
- Simple branded DK icon treatment in the app header

## Storage

Data is stored in the app's private SQLite database (`dokankhata.db`). It stays on this phone.
Uninstalling the app or clearing its app data can remove the records. Export/restore and cloud sync are not included in this first version.

## Notes

This is a complete Android Studio source project, not a precompiled APK. Build the APK from Android Studio using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
