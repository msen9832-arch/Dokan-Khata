package com.dokankhata.app

import android.app.DatePickerDialog
import android.os.Bundle
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF171717)
private val Paper = Color(0xFFFFFDF8)
private val Muted = Color(0xFF77736B)
private val Accent = Color(0xFF173D59)
private val Line = Color(0xFF292929)

data class LedgerPage(
    val id: Long = 0,
    val date: String,
    val sales: String = "",
    val stock: String = "",
    val cash: String = "",
    val due: String = "",
    val note: String = ""
)

class LedgerDb(context: Context) : SQLiteOpenHelper(context, "dokankhata.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE pages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT NOT NULL UNIQUE,
                sales TEXT NOT NULL DEFAULT '',
                stock TEXT NOT NULL DEFAULT '',
                cash TEXT NOT NULL DEFAULT '',
                due TEXT NOT NULL DEFAULT '',
                note TEXT NOT NULL DEFAULT ''
            )"""
        )
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun allPages(): List<LedgerPage> {
        val result = mutableListOf<LedgerPage>()
        readableDatabase.rawQuery("SELECT * FROM pages ORDER BY date DESC", null).use { c ->
            while (c.moveToNext()) result.add(
                LedgerPage(c.getLong(0), c.getString(1), c.getString(2), c.getString(3),
                    c.getString(4), c.getString(5), c.getString(6))
            )
        }
        return result
    }

    fun findByDate(date: String): LedgerPage? {
        readableDatabase.rawQuery("SELECT * FROM pages WHERE date=?", arrayOf(date)).use { c ->
            if (c.moveToFirst()) return LedgerPage(
                c.getLong(0), c.getString(1), c.getString(2), c.getString(3),
                c.getString(4), c.getString(5), c.getString(6)
            )
        }
        return null
    }

    fun save(page: LedgerPage): Long {
        val values = ContentValues().apply {
            put("date", page.date); put("sales", page.sales); put("stock", page.stock)
            put("cash", page.cash); put("due", page.due); put("note", page.note)
        }
        writableDatabase.insertWithOnConflict("pages", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        return findByDate(page.date)?.id ?: -1L
    }

    fun delete(id: Long) {
        writableDatabase.delete("pages", "id=?", arrayOf(id.toString()))
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = LedgerDb(this)
        setContent { DokanKhataApp(db) }
    }
}

private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
private fun displayDate(date: String): String = try {
    val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)!!
    SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(parsed)
} catch (_: Exception) { date }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DokanKhataApp(db: LedgerDb) {
    var pages by remember { mutableStateOf(db.allPages()) }
    var selected by remember { mutableStateOf<LedgerPage?>(null) }
    var search by remember { mutableStateOf("") }
    var showDelete by remember { mutableStateOf(false) }
    val context = LocalContext.current

    fun refresh() { pages = db.allPages() }
    fun openDate(date: String) {
        val existing = db.findByDate(date)
        selected = existing ?: LedgerPage(date = date)
    }
    fun pickDate(initial: String = today(), onPicked: (String) -> Unit) {
        val parts = initial.split("-")
        val y = parts.getOrNull(0)?.toIntOrNull() ?: 2026
        val m = (parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1
        val d = parts.getOrNull(2)?.toIntOrNull() ?: 1
        DatePickerDialog(context, { _, year, month, day ->
            onPicked(String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day))
        }, y, m, d).show()
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Accent, onPrimary = Color.White, background = Paper,
            surface = Paper, onSurface = Ink
        )
    ) {
        if (selected != null) {
            LedgerEditor(
                initial = selected!!,
                pageNumber = (pages.sortedBy { it.date }.indexOfFirst { it.date == selected!!.date } + 1)
                    .let { if (it <= 0) pages.size + 1 else it },
                onBack = { refresh(); selected = null },
                onSave = { page ->
                    db.save(page)
                    selected = page.copy(id = db.findByDate(page.date)?.id ?: page.id)
                    refresh()
                },
                onDelete = { page ->
                    if (page.id != 0L) db.delete(page.id)
                    refresh(); selected = null
                },
                onPickDate = { current, callback -> pickDate(current, callback) }
            )
        } else {
            Scaffold(
                containerColor = Paper,
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = { openDate(today()) },
                        containerColor = Accent,
                        contentColor = Color.White
                    ) { Icon(Icons.Default.Add, contentDescription = "New page") }
                }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(48.dp).background(Accent, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("DK", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("DokanKhata", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text("Your daily shop ledger", fontSize = 12.sp, color = Muted)
                        }
                        Text("${pages.size} pages", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(22.dp))
                    OutlinedTextField(
                        value = search, onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search by date (e.g. 2026-11-24)") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        trailingIcon = {
                            IconButton(onClick = { pickDate { search = it } }) {
                                Icon(Icons.Default.CalendarMonth, "Choose date")
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                    Spacer(Modifier.height(18.dp))
                    Text("YOUR PAGES", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        color = Muted, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(10.dp))
                    val filtered = pages.filter {
                        it.date.contains(search.trim(), ignoreCase = true) ||
                            displayDate(it.date).contains(search.trim(), ignoreCase = true)
                    }
                    if (filtered.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (search.isBlank()) "No pages yet" else "No matching pages",
                                    fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(6.dp))
                                Text("Tap + to create your first daily page", color = Muted, fontSize = 13.sp)
                            }
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 90.dp)) {
                            items(filtered, key = { it.id }) { page ->
                                Card(
                                    modifier = Modifier.fillMaxWidth().clickable { selected = page },
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    shape = RoundedCornerShape(14.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE8E4DC))
                                ) {
                                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(displayDate(page.date), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                            Text("বিক্রি: ${page.sales.ifBlank { "—" }}   •   বাকি: ${page.due.ifBlank { "—" }}",
                                                color = Muted, fontSize = 12.sp, maxLines = 1,
                                                overflow = TextOverflow.Ellipsis)
                                        }
                                        Text("OPEN  ›", color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LedgerEditor(
    initial: LedgerPage,
    pageNumber: Int,
    onBack: () -> Unit,
    onSave: (LedgerPage) -> Unit,
    onDelete: (LedgerPage) -> Unit,
    onPickDate: (String, (String) -> Unit) -> Unit
) {
    var page by remember(initial.id, initial.date) { mutableStateOf(initial) }
    var savedLabel by remember { mutableStateOf("Saved on this device") }

    fun update(newPage: LedgerPage) {
        page = newPage
        onSave(newPage)
        savedLabel = "Saved on this device"
    }

    Column(Modifier.fillMaxSize().background(Paper)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text("Daily Ledger", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(savedLabel, color = Muted, fontSize = 11.sp)
            }
            IconButton(onClick = { onPickDate(page.date) { newDate -> update(page.copy(date = newDate)) } }) {
                Icon(Icons.Default.CalendarMonth, "Change date")
            }
            IconButton(onClick = { onDelete(page) }) {
                Icon(Icons.Default.Delete, "Delete page", tint = Color(0xFFB3261E))
            }
        }
        Divider(color = Line, thickness = 2.dp)
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("তারিখ", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text(displayDate(page.date), fontSize = 16.sp)
                Text("Page - $pageNumber", fontSize = 12.sp, color = Muted)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("DOKANKHATA", fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                Text("Daily account book", fontSize = 10.sp, color = Muted)
            }
        }
        Divider(color = Line, thickness = 2.dp)
        Row(Modifier.fillMaxWidth().height(64.dp)) {
            LedgerHeader("বিক্রি", Modifier.weight(1f))
            LedgerHeader("মালামাল", Modifier.weight(1f))
            LedgerHeader("ক্যাশ", Modifier.weight(1f))
            LedgerHeader("বাকি", Modifier.weight(1f))
        }
        Divider(color = Line, thickness = 2.dp)
        Row(Modifier.fillMaxWidth().weight(1f)) {
            LedgerCell(page.sales, { update(page.copy(sales = it)) }, Modifier.weight(1f))
            LedgerCell(page.stock, { update(page.copy(stock = it)) }, Modifier.weight(1f))
            LedgerCell(page.cash, { update(page.copy(cash = it)) }, Modifier.weight(1f))
            LedgerCell(page.due, { update(page.copy(due = it)) }, Modifier.weight(1f))
        }
        Divider(color = Line, thickness = 2.dp)
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text("অতিরিক্ত নোট", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = page.note,
                onValueChange = { update(page.copy(note = it)) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Write any extra details...") },
                minLines = 2,
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text("Changes are saved automatically on this phone.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun LedgerHeader(label: String, modifier: Modifier = Modifier) {
    Box(
        modifier.fillMaxHeight().border(1.dp, Line).background(Color(0xFFF5F0E7)).padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink,
            maxLines = 1, softWrap = false)
    }
}

@Composable
fun LedgerCell(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxHeight().border(1.dp, Line).padding(5.dp)) {
        BasicTextField(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.fillMaxSize(),
            textStyle = androidx.compose.ui.text.TextStyle(
                color = Ink, fontSize = 15.sp, lineHeight = 22.sp
            ),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            decorationBox = { inner ->
                Box(Modifier.fillMaxSize()) {
                    if (value.isEmpty()) {
                        Text("লিখুন...", color = Color(0xFFB4AEA4), fontSize = 12.sp)
                    }
                    inner()
                }
            }
        )
    }
}
